package com.statestreet.service;

public interface Loan {
	String getMessage();
}
