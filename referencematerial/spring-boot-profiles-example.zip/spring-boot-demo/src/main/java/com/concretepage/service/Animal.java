package com.concretepage.service;

public interface Animal {
	String getMessage();
}
