package com.baeldung.greeter;

import java.util.Properties;

public class GreetingConfig extends Properties{
    
    private static final long serialVersionUID = 5662570853707247891L;

}
