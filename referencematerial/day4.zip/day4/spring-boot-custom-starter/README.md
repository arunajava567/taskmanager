### Relevant Articles: 
- [Creating a Custom Starter with Spring Boot](http://www.baeldung.com/spring-boot-custom-starter)
