package com.statestreet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.statestreet.service.Loan;

@RestController
public class LoanController {
   @Autowired
   private Loan loan;	
   @GetMapping("/")	
   public String getMessage() {
	   return loan.getMessage();
   }
}
