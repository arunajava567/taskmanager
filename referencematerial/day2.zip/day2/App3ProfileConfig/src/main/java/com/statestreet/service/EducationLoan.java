package com.statestreet.service;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("loan_prod")
public class EducationLoan implements Loan {
	//@Override
	public String getMessage() {
		return "Interest rate is 11%";
	}
}
