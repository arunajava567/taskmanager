package com.statestreet.service;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("loan_dev")
public class HousingLoan implements Loan {
	//@Override
	public String getMessage() {
		return "Interest Rate is 8.75%";
	}

}
