package com.ss.test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MokitoDemoApplication {
   public static void main(String[] args) {
      SpringApplication.run(MokitoDemoApplication.class, args);
   }
}