CREATE TABLE `products` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `description` VARCHAR(50) NULL ,
  `weight` DECIMAL(5,2) NULL ,
  `price` DECIMAL(5,2) NULL ,
  `mfg_date` DATE NULL ,
  `use_before_months` INT NULL ,
  `expiry_date` DATE NULL ,
PRIMARY KEY (`id`) );


CREATE TABLE users (
	username varchar(50) primary key,
	password varchar(100),
	role varchar(50),
	full_name varchar(50),
	country varchar(50),
	enabled integer);


INSERT INTO users VALUES ("james", "pwd123","ROLE_USER","James Bond","UK",1);

INSERT INTO users VALUES ("daniel", "pwd124","ROLE_ADMIN","Daniel Craig","UK",1);

