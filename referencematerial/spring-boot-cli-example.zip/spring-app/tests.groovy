class ApplicationTests {
    @Test
    void HelloAppTest() {
        assertEquals("Hello World!", new HelloController().home())
    }
}