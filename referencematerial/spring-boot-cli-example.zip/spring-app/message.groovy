@Controller
@Grab('spring-boot-starter-thymeleaf')
class MessageController {
    @RequestMapping("/msg")
	String getMsg(Model model) {
    	String msg = "Welcome to Everyone!";
        model.addAttribute("message", msg);
        return "hello";
    }
}


